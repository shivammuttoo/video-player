import './App.css';
import VideoPlayer from './components/video-player'
function App() {
  return (
    <div className="App">
      <VideoPlayer></VideoPlayer>
    </div>
  );
}

export default App;
