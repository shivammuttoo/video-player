import React from "react";
import styled from "styled-components";
const Image = styled.img`
        float: right;
        padding: 10px;
    `;
const Logo = () =>{    
    return(
        <div>
            <Image src="https://static.files.bbci.co.uk/orbit/8161b75793cc3c38d814e1a4a19a2f6a/img/blq-orbit-blocks_grey.svg" />

        </div>
    )
}
export default Logo