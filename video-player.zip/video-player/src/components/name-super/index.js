import React from 'react';
import styled from 'styled-components';
const Heading = styled.h3`
    display: flex;
    margin-left: 0.5pc;
    font-size: 1.5vw;
`
const Container = styled.div`
    top: 70%;
    position: relative;
    border-left: 5px solid #c92626;
`
const NameSuper = (props) =>{
    
    return(
        <Container>
        { 
            Object.entries(props.captionData).map((elem)=>{
                return <Heading key={elem[0]}>
                            {elem[1]}
                        </Heading>
            })                
       } 
        </Container>
       
    )
}
export default NameSuper