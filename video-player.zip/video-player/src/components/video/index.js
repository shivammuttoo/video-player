import React from "react";
import styled from "styled-components";

const Vid = styled.video`
    width:100%;
    `
class Video extends React.PureComponent{
    constructor(props){
        super(props)
    }

    render(){
        return (
            <Vid ref={this.props.videoElem} onTimeUpdate={this.props.onTimeUpdate} id="my-video" src="https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/1080/Big_Buck_Bunny_1080_10s_10MB.mp4" controls />
        )
    }

}
export default Video;
