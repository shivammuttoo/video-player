import React, {createRef} from "react";
import styled from "styled-components";
import NameSuper from "../name-super";
import Logo from "../logo";
import Video from "../video";
import OverlayWrapper from "../../Wrapper/OverlayWrapper";
import { evtArray } from "../../utils";
const Container = styled.div`
     width: 100%;   
    
`
const InnerContainer = styled.div`
    max-width: 800px;
    position: relative;
    top: 0;
    bottom: 0;
    
`
const Overlay = styled.div`
    position: absolute;
    width: 100%;
    height: 100%;
    color: white;
`
const ON = 'On';
const OFF = 'Off'
class VideoPlayer extends React.Component{
    constructor(props){
        super(props)
        this.state = {currentTime: 0.0, overlayVisible: ON}

    }
    videoElem = createRef()
    
    /*
        method to return component dynamically on the basis of captionType
    */
    getComponent = (props) =>{
        switch (props.captionType){
            case 'nameSuper':
                return (
                    <OverlayWrapper key={props.id} videoElem={this.videoElem} {...props}>
                        <NameSuper {...props}/>
                    </OverlayWrapper>
                )
            case 'logo':
                return(
                    <OverlayWrapper key={props.id} videoElem={this.videoElem} {...props}>
                        <Logo  {...props}/>
                    </OverlayWrapper>
                )   
            default:
                return <></>             
        }
            
    }
    onTimeUpdate = (event) =>{
        this.setState({
            currentTime: event.target.currentTime * 1000
        })
    }
    // to turn overlay on and off
    overlayToggle = () =>{
        this.state.overlayVisible === ON ? this.setState({overlayVisible: OFF})
                                         : this.setState({overlayVisible: ON})
    }
    render(){
        return<> 
                    <Container>
                        <InnerContainer>
                            {this.state.overlayVisible === ON &&
                                <Overlay>                                
                                    {
                                        evtArray.map((elem)=>{
                                            return (this.getComponent({currentTime:this.state.currentTime,...elem}))
                                        })
                                    }                            
                                </Overlay> 
                            }                     
                            <Video videoElem={this.videoElem} onTimeUpdate={this.onTimeUpdate.bind(this)} />                        
                        </InnerContainer>                    
                            <button onClick={this.overlayToggle}>Overlay {this.state.overlayVisible}</button>    
                    </Container>
                </>
                
    }
}
export default VideoPlayer;