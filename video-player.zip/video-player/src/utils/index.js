// to convert give timeline into ms.
const convertIntoTime = (time) =>{
    const [hours, min, sec, frame] = time.split(':');
    const FPS = 29.97 // taking constant FPS as 29.97
    const ms = (hours * 60 * 60 * 1000) + (min * 60 * 1000) + (sec * 1000)
    const frameTime =  Math.round((frame/FPS)*1000);
    return frameTime + ms;
}
// array of event objects 
export const evtArray = [
    {
        id:0,
        startTime: "00:00:01:00",
        endTime: "00:00:10:00",
        captionType: "logo",
        cationData:{
            action: 'on',
            location: 'top left'
        },
    },
    {
        id:1,
        startTime: "00:00:02:00",
        endTime: "00:00:03:20",
        captionType: "nameSuper",
        captionData:{
            line1: "a rabbit hole"
            
        },
    },
    {
        id:2,
        startTime: "00:00:04:00",
        endTime: "00:00:05:10",
        captionType: "nameSuper",
        captionData:{
            line1: "a rabbit 123",
            line2: "( a big tree )"
        },
    },
    {
        id:3,
        startTime: "00:00:06:00",
        endTime: "00:00:06:20",
        captionType: "nameSuper",
        captionData:{
            line1: "some rocks",
        },
    },
    {
        id:4,
        startTime: "00:00:07:00",
        endTime: "00:00:08:14",
        captionType: "nameSuper",
        captionData:{
            line1: "some grass",
        },
    },
    {
        id:5,
        startTime: "00:00:09:00",
        endTime: "00:00:10:00",
        captionType: "title",
        captionData:{
            text: "the end",
        },
    },
    
];
export default convertIntoTime;