import React, {useEffect} from "react";
import convertIntoTime from '../utils';
// OverlayWrapper to keep common logic (i.e start and stop)
const OverlayWrapper = (props) =>{
    const startTime = convertIntoTime(props.startTime)
    const endTime = convertIntoTime(props.endTime)
    const isVisible = props.currentTime >= startTime  && props.currentTime < endTime
    useEffect(()=>{
        if(isVisible){
            // to pause the video upon timecode reaches startTime
            props.videoElem.current.pause();
        }
    },[isVisible])
    return (
       <>
            {isVisible && props.children}
       </>
    )
}
export default OverlayWrapper;